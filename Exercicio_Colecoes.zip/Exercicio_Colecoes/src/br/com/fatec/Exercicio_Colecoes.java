/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec;

import java.util.HashSet;
import java.util.Set;


/**
 *
 * @author Jo4oV
 */
public class Exercicio_Colecoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      Proprietario prop = new Proprietario(new Veiculo());
      Veiculo car = new Veiculo();
      
      prop.setNome("Joao");
      prop.setCpf("341224");
      
      car.setPlaca("123abc");
      car.setValor(100.000f);
      
      Veiculo car2 = new Veiculo();
      
      car2.setPlaca("222bbc");
      car2.setValor(100.000f);
      
      prop.AddVeiculo(car);
      prop.AddVeiculo(car2);
      
      
      prop.getVeiculo().setPlaca("432ucv");
      prop.getVeiculo().setValor(100.000f);
      Veiculo car3 = new Veiculo();
      car3.setPlaca("173avc");
      
      System.out.println("Total: " + prop.Valbens());
      
      
     
      
      for(Veiculo aux : prop.addcar){
          System.out.println("Carros Pela Placa: " + aux.getPlaca());
      }
     // prop.setVeiculo(car);
      
      
  
    }   
}
