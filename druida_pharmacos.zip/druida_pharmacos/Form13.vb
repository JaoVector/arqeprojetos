﻿Public Class Form13


    Private Sub btn_pedimanipu_Click(sender As Object, e As EventArgs) Handles btn_pedimanipu.Click

        Form10.ShowDialog()

    End Sub

    Private Sub btn_pedcontro_Click(sender As Object, e As EventArgs) Handles btn_pedcontro.Click

        Form11.ShowDialog()


    End Sub

    Private Sub btn_pedrogaria_Click(sender As Object, e As EventArgs) Handles btn_pedrogaria.Click

        Form12.ShowDialog()


    End Sub

    Private Sub btn_etmanipu_Click(sender As Object, e As EventArgs) Handles btn_etmanipu.Click

        Form5.ShowDialog()


    End Sub

    Private Sub btn_econtro_Click(sender As Object, e As EventArgs) Handles btn_econtro.Click

        Form6.ShowDialog()


    End Sub

    Private Sub btn_edrog_Click(sender As Object, e As EventArgs) Handles btn_edrog.Click

        Form9.ShowDialog()


    End Sub

    Private Sub btn_cadfun_Click(sender As Object, e As EventArgs) Handles btn_cadfun.Click

        Form7.ShowDialog()


    End Sub

    Private Sub btn_delfun_Click(sender As Object, e As EventArgs) Handles btn_delfun.Click

        Form14.ShowDialog()


    End Sub


    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click


        Me.Close()
        Form2.Show()

    End Sub

    Private Sub Form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub
End Class