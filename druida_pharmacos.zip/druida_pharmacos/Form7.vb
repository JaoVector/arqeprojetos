﻿Public Class Form7

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco()
        categ_funcio()
    End Sub

    Private Sub btn_cad_Click(sender As Object, e As EventArgs) Handles btn_cad.Click

        sql = "insert into tb_funcionarios values ('" & txt_cpf.Text & "', " &
                                                  "'" & txt_data1.Text & "', " &
                                                  "'" & txt_user.Text & "', " &
                                                  "'" & cmb_categ.Text & "', " &
                                                  "'" & txt_email.Text & "', " &
                                                  "'" & txt_fone.Text & "', " &
                                                  "'" & txt_cel.Text & "')"

        rs = db.Execute(UCase(sql))
        MsgBox("Dados gravados", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
        limpar_cadastro_funcio()
    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form13.Show()


    End Sub
End Class