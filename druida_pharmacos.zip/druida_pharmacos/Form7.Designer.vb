﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form7
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_user = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_cpf = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmb_categ = New System.Windows.Forms.ComboBox()
        Me.txt_email = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txt_cel = New System.Windows.Forms.MaskedTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_fone = New System.Windows.Forms.MaskedTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btn_cad = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_data1 = New System.Windows.Forms.DateTimePicker()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_fechar = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_user
        '
        Me.txt_user.Location = New System.Drawing.Point(12, 116)
        Me.txt_user.Name = "txt_user"
        Me.txt_user.Size = New System.Drawing.Size(331, 20)
        Me.txt_user.TabIndex = 36
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(135, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "NOME DO FUNCIONÁRIO"
        '
        'txt_cpf
        '
        Me.txt_cpf.Location = New System.Drawing.Point(12, 70)
        Me.txt_cpf.Mask = "999,999,999-99"
        Me.txt_cpf.Name = "txt_cpf"
        Me.txt_cpf.Size = New System.Drawing.Size(120, 20)
        Me.txt_cpf.TabIndex = 32
        Me.txt_cpf.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 13)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "CPF DO FUNCIONÁRIO"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 147)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 13)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "CATEGORIA"
        '
        'cmb_categ
        '
        Me.cmb_categ.FormattingEnabled = True
        Me.cmb_categ.Location = New System.Drawing.Point(12, 163)
        Me.cmb_categ.Name = "cmb_categ"
        Me.cmb_categ.Size = New System.Drawing.Size(120, 21)
        Me.cmb_categ.TabIndex = 38
        '
        'txt_email
        '
        Me.txt_email.Location = New System.Drawing.Point(158, 164)
        Me.txt_email.Name = "txt_email"
        Me.txt_email.Size = New System.Drawing.Size(185, 20)
        Me.txt_email.TabIndex = 54
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(155, 148)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(39, 13)
        Me.Label12.TabIndex = 53
        Me.Label12.Text = "EMAIL"
        '
        'txt_cel
        '
        Me.txt_cel.Location = New System.Drawing.Point(158, 210)
        Me.txt_cel.Mask = "(99) 99999-9999"
        Me.txt_cel.Name = "txt_cel"
        Me.txt_cel.Size = New System.Drawing.Size(117, 20)
        Me.txt_cel.TabIndex = 52
        Me.txt_cel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(155, 194)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 13)
        Me.Label11.TabIndex = 51
        Me.Label11.Text = "CELULAR"
        '
        'txt_fone
        '
        Me.txt_fone.Location = New System.Drawing.Point(15, 210)
        Me.txt_fone.Mask = "(99) 9999-9999"
        Me.txt_fone.Name = "txt_fone"
        Me.txt_fone.Size = New System.Drawing.Size(117, 20)
        Me.txt_fone.TabIndex = 50
        Me.txt_fone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 194)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 13)
        Me.Label10.TabIndex = 49
        Me.Label10.Text = "FONE RESIDENCIAL"
        '
        'btn_cad
        '
        Me.btn_cad.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_cad.Location = New System.Drawing.Point(111, 252)
        Me.btn_cad.Name = "btn_cad"
        Me.btn_cad.Size = New System.Drawing.Size(100, 25)
        Me.btn_cad.TabIndex = 57
        Me.btn_cad.Text = "CADASTRAR"
        Me.btn_cad.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(233, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(110, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "DATA NASCIMENTO"
        '
        'txt_data1
        '
        Me.txt_data1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txt_data1.Location = New System.Drawing.Point(236, 70)
        Me.txt_data1.MinDate = New Date(1900, 1, 1, 0, 0, 0, 0)
        Me.txt_data1.Name = "txt_data1"
        Me.txt_data1.Size = New System.Drawing.Size(107, 20)
        Me.txt_data1.TabIndex = 59
        Me.txt_data1.Value = New Date(2019, 10, 17, 0, 0, 0, 0)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_fechar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(358, 25)
        Me.ToolStrip1.TabIndex = 60
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_fechar
        '
        Me.btn_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_fechar.Image = Global.druida_pharmacos.My.Resources.Resources.close_2_icon
        Me.btn_fechar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_fechar.Name = "btn_fechar"
        Me.btn_fechar.Size = New System.Drawing.Size(23, 22)
        Me.btn_fechar.Text = "FECHAR"
        '
        'Form7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(358, 304)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.txt_data1)
        Me.Controls.Add(Me.btn_cad)
        Me.Controls.Add(Me.txt_email)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.txt_cel)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txt_fone)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cmb_categ)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_user)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_cpf)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form7"
        Me.Text = "CADASTRO DE FUNCIONÁRIOS"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_user As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cmb_categ As ComboBox
    Friend WithEvents txt_email As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txt_cel As MaskedTextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txt_fone As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents btn_cad As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_data1 As DateTimePicker
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_fechar As ToolStripButton
End Class
