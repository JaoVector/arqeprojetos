﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        rem_esp1_form4()
        rem_esp2_form4()
        rem_esp3_form4()

    End Sub


    Private Sub txt_fml1_LostFocus(sender As Object, e As EventArgs) Handles txt_fml1.LostFocus
        ' PEDIDOS DE MANIPULAVEIS
        ' BUSCA NA TABELA DE ESTOQUE DE MANIPULAVEIS

        Try

            sql = "select * from tb_emanipulaveis where fml1= '" & txt_fml1.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_pa1.Text = rs.Fields(1).Value
                txt_mg1.Text = rs.Fields(2).Value
                cmb_esp.Text = rs.Fields(3).Value
                txt_preco1.Text = rs.Fields(5).Value
                txt_pres1.Focus()

            Else

                MsgBox("Fórmula Não Existe no banco", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")

            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try


    End Sub

    Private Sub txt_cpf1_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf1.LostFocus
        'PEDIDOS MANIPULAVEIS
        'BUSCA NA TABELA DE CADASTRO O CPF

        Try


            sql = "select * from tb_cadastro where cpf= '" & txt_cpf1.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_nome1.Text = rs.Fields(2).Value

            Else

                MsgBox("CPF não Existe", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try
    End Sub

    Private Sub txt_cpf2_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf2.LostFocus
        'PEDIDOS NA TABELA DE CONTROLADOS
        'BUSCA NA TB_CADASTRO O CPF
        Try


            sql = "select * from tb_cadastro where cpf='" & txt_cpf2.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_nome2.Text = rs.Fields(2).Value

            Else

                MsgBox("CPF não Existe", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try



    End Sub

    Private Sub txt_fml2_LostFocus(sender As Object, e As EventArgs) Handles txt_fml2.LostFocus

        'BUSCA NA TABELA DE CONTROLADOS
        'TABELA DE PEDIDOS CONTROLADOS

        Try

            sql = "select * from tb_econtrolados where fml2='" & txt_fml2.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_sub1.Text = rs.Fields(1).Value
                txt_mg2.Text = rs.Fields(2).Value
                cmb_esp2.Text = rs.Fields(3).Value
                txt_preco2.Text = rs.Fields(5).Value
                txt_pres2.Focus()

            Else

                MsgBox("Fórmula Não Existe no banco", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")

            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try

    End Sub

    Private Sub txt_cpf3_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf3.LostFocus

        'BUSCA NA TABELA DE CADASTRO
        'PEDIDOS DE DROGARIA

        Try


            sql = "select * from tb_cadastro where cpf='" & txt_cpf3.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_nome3.Text = rs.Fields(2).Value

            Else

                MsgBox("CPF não Existe", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try



    End Sub

    Private Sub txt_fml3_LostFocus(sender As Object, e As EventArgs) Handles txt_fml3.LostFocus

        'BUSCA DENTRO DA TABELA DE DROGARIA

        Try

            sql = "select * from tb_edrogaria where fml3='" & txt_fml3.Text & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                txt_sub2.Text = rs.Fields(1).Value
                txt_mg3.Text = rs.Fields(2).Value
                cmb_esp3.Text = rs.Fields(3).Value
                txt_preco3.Text = rs.Fields(5).Value
                txt_pres3.Focus()

            Else

                MsgBox("Fórmula Não Existe no banco", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")

            End If

        Catch ex As Exception

            MsgBox("DEU ERRO!!!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")


        End Try

    End Sub

    Private Sub btn_save1_Click(sender As Object, e As EventArgs) Handles btn_save1.Click

        'CADASTRO DO PEDIDO DE MANIPULAVEIS

        gerar_id_usuario1()

        sql = "insert into tb_pmanipulaveis values ('" & id_produto1.ToString & "', " &
                                                   "'" & txt_cpf1.Text & "', " &
                                                   "'" & txt_data1.Text & "', " &
                                                   "'" & txt_nome1.Text & "', " &
                                                   "'" & txt_pres1.Text & "', " &
                                                   "'" & txt_pa1.Text & "', " &
                                                   "'" & txt_fml1.Text & "', " &
                                                   "'" & txt_mg1.Text & "', " &
                                                   "'" & cmb_esp.Text & "', " &
                                                   "'" & txt_preco1.Text & "')"

        rs = db.Execute(UCase(sql))
            MsgBox("Cadastro Efetuado com Sucesso!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        limpar_pedidos_manipu()



    End Sub

    Private Sub txt_save2_Click(sender As Object, e As EventArgs) Handles txt_save2.Click

        'CADASTRO DO PEDIDO DE CONTROLADOS
        gerar_id_usuario2()



        sql = "insert into tb_pcontrolados values ('" & id_produto2.ToString & "', " &
                                                  "'" & txt_cpf2.Text & "', " &
                                                  "'" & txt_data2.Text & "', " &
                                                  "'" & txt_nome2.Text & "', " &
                                                  "'" & txt_pres2.Text & "', " &
                                                  "'" & txt_sub1.Text & "', " &
                                                  "'" & txt_fml2.Text & "', " &
                                                  "'" & txt_mg2.Text & "', " &
                                                  "'" & cmb_esp2.Text & "', " &
                                                  "'" & txt_preco2.Text & "')"

        rs = db.Execute(UCase(sql))
            MsgBox("Cadastro Efetuado com Sucesso!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        limpar_pedidos_controla()



    End Sub

    Private Sub txt_save3_Click(sender As Object, e As EventArgs) Handles txt_save3.Click

        'CADASTRO DO PEDIDO DE DROGARIA
        gerar_id_usuario3()
        Try


            sql = "insert into tb_pdrogaria values ('" & id_produto3.ToString & "', " &
                                                   "'" & txt_cpf3.Text & "', " &
                                                   "'" & txt_data3.Text & "', " &
                                                   "'" & txt_nome3.Text & "', " &
                                                   "'" & txt_pres3.Text & "', " &
                                                   "'" & txt_sub2.Text & "', " &
                                                   "'" & txt_fml3.Text & "', " &
                                                   "'" & txt_mg3.Text & "', " &
                                                   "'" & cmb_esp3.Text & "', " &
                                                   "'" & txt_preco3.Text & "')"

            rs = db.Execute(UCase(sql))
            MsgBox("Cadastro Efetuado com Sucesso!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            limpar_pedidos_drogaria()


        Catch ex As Exception
            MsgBox("Erro ao Gravar!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "AVISO")
        End Try



    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click


        Me.Close()
        Form8.Show()

    End Sub
End Class