﻿Public Class Form14


    Private Sub Form14_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        categ_funcio_dados()
        gerar_dados_funcionario()

    End Sub

    Private Sub dgv_funcio_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_funcio.CellContentClick

        Try


            With dgv_funcio
                If .CurrentRow.Cells(7).Selected = True Then
                    aux = .CurrentRow.Cells(1).Value.ToString
                    resp = MsgBox("Deseja deletar o Pedido do" + vbNewLine &
                                  "CPF:" & aux & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = "delete * from tb_funcionarios where cpf= '" & aux & "'"
                        rs = db.Execute(sql)
                        gerar_dados_funcionario()
                    End If

                Else
                    Exit Sub

                End If

            End With

        Catch ex As Exception
            MsgBox("Deu RUIM ARTHUR!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Private Sub txt_busca2_TextChanged(sender As Object, e As EventArgs) Handles txt_busca2.TextChanged

        sql = "select * from tb_funcionarios where " & cmb_funcio.Text & " like '" & txt_busca2.Text & "%'"
        rs = db.Execute(sql)
        With dgv_funcio
            .Rows.Clear()
            Do While rs.EOF = False

                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, rs.Fields(7).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form13.Show()

    End Sub
End Class