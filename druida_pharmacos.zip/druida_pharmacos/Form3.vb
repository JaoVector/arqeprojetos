﻿Public Class Form3

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        rem_esp1_form3()
        rem_esp2_form3()
        rem_esp3_form3()

    End Sub
    Private Sub btn_salvar3_Click(sender As Object, e As EventArgs) Handles btn_salvar3.Click

        'tb estoque de drogaria
        Try

            sql = "insert into tb_edrogaria values ('" & txt_fml3.Text & "', " &
                                                   "'" & txt_sub2.Text & "', " &
                                                   "'" & txt_mg3.Text & "', " &
                                                   "'" & cmb_esp3.Text & "'," &
                                                   "'" & txt_preco3.Text & "', " &
                                                   "'" & qtd3.Text & "')"

            rs = db.Execute(UCase(sql))
            MsgBox("Dados Gravados!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            limpar_edrogaria()
        Catch ex As Exception

            MsgBox("ERRO!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

        End Try

    End Sub

    Private Sub btn_salvar2_Click(sender As Object, e As EventArgs) Handles btn_salvar2.Click

        'tb estoque de controlados
        Try

            contr = "insert into tb_econtrolados values ('" & txt_fml2.Text & "', " &
                                                        "'" & txt_sub1.Text & "', " &
                                                        "'" & txt_mg2.Text & "', " &
                                                        "'" & cmb_esp2.Text & "', " &
                                                        "'" & txt_preco2.Text & "', " &
                                                        "'" & qtd2.Text & "')"

            rs = db.Execute(UCase(contr))
            MsgBox("Dados Gravados!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            limpar_econtrolados()
        Catch ex As Exception

            MsgBox("ERRO!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

        End Try

    End Sub

    Private Sub btn_save1_Click(sender As Object, e As EventArgs) Handles btn_save1.Click

        Try

            mani = "insert into tb_emanipulaveis values ('" & txt_fml1.Text & "', " &
                                                        "'" & txt_pa1.Text & "', " &
                                                        "'" & txt_mg1.Text & "', " &
                                                        "'" & cmb_esp.Text & "'," &
                                                        "'" & txt_preco1.Text & "', " &
                                                        "'" & qtd1.Text & "')"

            rs = db.Execute(UCase(mani))
            MsgBox("Dados Gravados!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            limpar_esmanipulaveis()
        Catch ex As Exception

            MsgBox("ERRO!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

        End Try

    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click


        Me.Close()
        Form8.Show()

    End Sub
End Class