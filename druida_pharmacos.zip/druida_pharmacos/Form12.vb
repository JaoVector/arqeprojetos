﻿Public Class Form12


    Private Sub dgv_pedrogaria_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_pedrogaria.CellContentClick

        Try


            With dgv_pedrogaria
                If .CurrentRow.Cells(10).Selected = True Then
                    aux = .CurrentRow.Cells(1).Value.ToString
                    resp = MsgBox("Deseja deletar o registro" + vbNewLine &
                                  "Fórmula:" & aux & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = "delete * from tb_pdrogaria where cpf3= '" & aux & "'"
                        rs = db.Execute(sql)
                        gerar_dados_pdrogaria()
                    End If

                Else
                    Exit Sub

                End If

            End With

        Catch ex As Exception
            MsgBox("Deu RUIM ARTHUR!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Private Sub txt_busca2_TextChanged(sender As Object, e As EventArgs) Handles txt_busca2.TextChanged

        sql = "select * from tb_pdrogaria where " & cmb_pedrogaria.Text & " like '" & txt_busca2.Text & "%'"
        rs = db.Execute(sql)
        With dgv_pedrogaria
            .Rows.Clear()
            Do While rs.EOF = False

                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, rs.Fields(7).Value, rs.Fields(8).Value, rs.Fields(9).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub

    Private Sub Form12_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        camp_pdrogaria()
        gerar_dados_pdrogaria()

    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form13.Show()

    End Sub
End Class