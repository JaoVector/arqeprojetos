﻿Module Module1

    Public diretorio As String
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public sql, aux, mani, contr As String
    Public conexao = Application.StartupPath & "\banco\druida_pharmacos.mdb"
    Public cont As Integer
    Public id_produto1, id_produto2, id_produto3 As Integer
    Public qtd1, qtd2, qtd3 As Integer
    Public manipulaveis, resp As String
    Public tab_control As String


    Sub conecta_banco()

        Try

            db = CreateObject("ADODB.Connection")
            db.Open("Provider=Microsoft.jet.OLEDB.4.0;Data Source=" & conexao)
            MsgBox("Conexao OK!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")


        Catch ex As Exception
            MsgBox("Conexao FALHOU!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Sub gerar_dados()
        sql = "select * from tb_cadastro order by nome asc"
        rs = db.Execute(sql)
        cont = 1
        With Form1.dgv_dados
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(2).Value, Nothing)
                rs.MoveNext()
                cont = cont + 1
            Loop
        End With
    End Sub

    Sub carregar_campos()

        With Form1.cmb_campo.Items

            .Add("CPF")
            .Add("NOME")

        End With
        Form1.cmb_campo.SelectedIndex = 1
    End Sub

    Sub rem_esp1_form3()
        With Form3.cmb_esp.Items

            .Add("D - Ins. Entorpecentes")
            .Add("D1 - Ins. Psicotrópicas")
            .Add("E - Plantas")
            .Add("F - Proscritos")


        End With
        Form3.cmb_esp.SelectedIndex = 1
    End Sub

    Sub rem_esp2_form3()
        With Form3.cmb_esp2.Items

            .Add("A - Entorpecentes")
            .Add("B - Psicotrópicos")
            .Add("C - Cont. Especial")
            .Add("C4 - Anti-Retrovirais")

        End With
        Form3.cmb_esp2.SelectedIndex = 1
    End Sub

    Sub rem_esp3_form3()
        With Form3.cmb_esp3.Items

            .Add("Genéricos")
            .Add("Anti-Inflamatórios")
            .Add("Contraceptivos")
            .Add("Cosméticos")

        End With
        Form3.cmb_esp3.SelectedIndex = 1

    End Sub

    Sub rem_esp1_form4()
        With Form4.cmb_esp.Items

            .Add("D - Ins. Entorpecentes")
            .Add("D1 - Ins. Psicotrópicas")
            .Add("E - Plantas")
            .Add("F - Proscritos")


        End With
        Form4.cmb_esp.SelectedIndex = 1
    End Sub

    Sub rem_esp2_form4()
        With Form4.cmb_esp2.Items

            .Add("A - Entorpecentes")
            .Add("B - Psicotrópicos")
            .Add("C - Cont. Especial")
            .Add("C4 - Anti-Retrovirais")

        End With
        Form4.cmb_esp2.SelectedIndex = 1
    End Sub

    Sub rem_esp3_form4()
        With Form4.cmb_esp3.Items

            .Add("Genéricos")
            .Add("Anti-Inflamatórios")
            .Add("Contraceptivos")
            .Add("Cosméticos")

        End With
        Form4.cmb_esp3.SelectedIndex = 1
    End Sub

    Sub categ_funcio()
        With Form7.cmb_categ.Items

            .Add("FUNCIONÁRIO")
            .Add("GERENTE")

        End With
        Form7.cmb_categ.SelectedIndex = 1
    End Sub

    Sub categ_funcio_login()
        With Form2.cmb_categ.Items

            .Add("FUNCIONÁRIO")
            .Add("GERENTE")

        End With
        Form2.cmb_categ.SelectedIndex = 1
    End Sub

    Sub categ_funcio_dados()
        With Form14.cmb_funcio.Items

            .Add("cpf")
            .Add("user")

        End With
        Form14.cmb_funcio.SelectedIndex = 1
    End Sub

    Sub gerar_id_usuario1()

        sql = "select * from tb_pmanipulaveis order by id_produto1 desc"
        rs = db.Execute(sql)

        If rs.BOF = True Then

            id_produto1 = 1

        Else

            id_produto1 = rs.Fields(0).Value + 1

        End If

    End Sub

    Sub gerar_id_usuario2()

        sql = "select * from tb_pcontrolados order by id_produto2 desc"
        rs = db.Execute(sql)

        If rs.BOF = True Then

            id_produto2 = 1

        Else

            id_produto2 = rs.Fields(0).Value + 1

        End If

    End Sub

    Sub gerar_id_usuario3()

        sql = "select * from tb_pdrogaria order by id_produto3 desc"
        rs = db.Execute(sql)

        If rs.BOF = True Then

            id_produto3 = 1

        Else

            id_produto3 = rs.Fields(0).Value + 1

        End If

    End Sub

    Sub camp_estoque_manipulaveis()

        With Form5.cmb_camp.Items


            .Add("pa1")
            .Add("esp1")

        End With
        Form5.cmb_camp.SelectedIndex = 1
    End Sub

    Sub camp_estoque_controlados()

        With Form6.cmb_camp2.Items


            .Add("sub1")
            .Add("esp2")

        End With
        Form6.cmb_camp2.SelectedIndex = 1
    End Sub


    Sub camp_estoque_drogaria()

        With Form9.cmb_camp3.Items


            .Add("sub2")
            .Add("esp3")

        End With
        Form9.cmb_camp3.SelectedIndex = 1
    End Sub
    Sub gerar_dados_manipulaveis()
        sql = "select * from tb_emanipulaveis order by pa1 asc"
        rs = db.Execute(sql)
        cont = 1
        With Form5.dgv_dados1
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                rs.MoveNext()
                cont = cont + 1
            Loop
        End With
    End Sub

    Sub gerar_dados_controlados()
        sql = "select * from tb_econtrolados order by sub1 asc"
        rs = db.Execute(sql)
        cont = 1
        With Form6.dgv_dados3
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                rs.MoveNext()
                cont = cont + 1
            Loop
        End With
    End Sub

    Sub gerar_dados_drogaria()
        sql = "select * from tb_edrogaria order by sub2 asc"
        rs = db.Execute(sql)
        cont = 1
        With Form9.dgv_dados2
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                rs.MoveNext()
                cont = cont + 1
            Loop
        End With
    End Sub

    'TABELAS DE PEDIDOS
    '---------------------------------------------
    Sub gerar_dados_pmanipulaveis()
        sql = "select * from tb_pmanipulaveis order by id_produto1 asc"
        rs = db.Execute(sql)
        With Form10.dgv_pedimanipu
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, rs.Fields(7).Value, rs.Fields(8).Value, rs.Fields(9).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub

    Sub gerar_dados_pcontrolados()
        sql = "select * from tb_pcontrolados order by id_produto2 asc"
        rs = db.Execute(sql)
        With Form11.dgv_pcontrol
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, rs.Fields(7).Value, rs.Fields(8).Value, rs.Fields(9).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub

    Sub gerar_dados_pdrogaria()
        sql = "select * from tb_pdrogaria order by id_produto3 asc"
        rs = db.Execute(sql)
        With Form12.dgv_pedrogaria
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, rs.Fields(7).Value, rs.Fields(8).Value, rs.Fields(9).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub


    Sub camp_pmanipulaveis()

        With Form10.cmb_pmani.Items


            .Add("cpf1")
            .Add("nome1")

        End With
        Form10.cmb_pmani.SelectedIndex = 1
    End Sub

    Sub camp_pcontrolados()

        With Form11.cmb_pedicontro.Items


            .Add("cpf2")
            .Add("nome2")

        End With
        Form11.cmb_pedicontro.SelectedIndex = 1
    End Sub

    Sub camp_pdrogaria()

        With Form12.cmb_pedrogaria.Items


            .Add("cpf3")
            .Add("nome3")

        End With
        Form12.cmb_pedrogaria.SelectedIndex = 1
    End Sub

    Sub gerar_dados_funcionario()
        sql = "select * from tb_funcionarios order by user asc"
        rs = db.Execute(sql)
        With Form14.dgv_funcio
            .Rows.Clear()

            Do While rs.EOF = False
                .Rows.Add(rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, rs.Fields(6).Value, Nothing)
                rs.MoveNext()
            Loop
        End With
    End Sub

    Sub limpar_cadastro()

        With Form1

            .txt_cpf.Clear()
            .txt_nome.Clear()
            .txt_cel.Clear()
            .txt_city.Clear()
            .txt_cep.Clear()
            .txt_comp.Clear()
            .txt_email.Clear()
            .txt_fone.Clear()
            .txt_uf.Clear()
            .txt_endereco.Clear()
            .txt_cel.Clear()
            .txt_bairro.Clear()
            .txt_busca.Clear()
            .txt_cpf.Focus()

        End With

    End Sub

    Sub limpar_cadastro_funcio()

        With Form7

            .txt_user.Clear()
            .txt_fone.Clear()
            .txt_cpf.Clear()
            .txt_email.Clear()
            .txt_cel.Clear()
            .txt_cpf.Focus()


        End With

    End Sub


    Sub limpar_esmanipulaveis()

        With Form3

            .txt_fml1.Clear()
            .txt_mg1.Clear()
            .txt_pa1.Clear()
            .txt_preco1.Clear()
            .qtd1.Clear()
            .txt_fml1.Focus()


        End With

    End Sub

    Sub limpar_econtrolados()

        With Form3

            .txt_fml2.Clear()
            .txt_mg2.Clear()
            .txt_preco2.Clear()
            .txt_sub1.Clear()
            .qtd2.Clear()
            .txt_fml2.Focus()

        End With

    End Sub

    Sub limpar_edrogaria()

        With Form3

            .txt_fml3.Clear()
            .txt_mg3.Clear()
            .txt_sub2.Clear()
            .txt_preco3.Clear()
            .qtd3.Clear()
            .txt_fml3.Focus()

        End With

    End Sub

    Sub limpar_pedidos_manipu()

        With Form4

            .txt_fml1.Clear()
            .txt_mg1.Clear()
            .txt_pa1.Clear()
            .txt_preco1.Clear()
            .txt_fml1.Focus()

        End With


    End Sub

    Sub limpar_pedidos_controla()

        With Form4

            .txt_fml2.Clear()
            .txt_mg2.Clear()
            .txt_preco2.Clear()
            .txt_sub1.Clear()
            .txt_fml2.Focus()

        End With

    End Sub

    Sub limpar_pedidos_drogaria()

        With Form4

            .txt_fml3.Clear()
            .txt_mg3.Clear()
            .txt_sub2.Clear()
            .txt_preco3.Clear()
            .txt_fml3.Focus()

        End With

    End Sub

    Sub limpar_login()

        With Form2

            .txt_cpf.Clear()
            .txt_cpf.Focus()

        End With

    End Sub

End Module
