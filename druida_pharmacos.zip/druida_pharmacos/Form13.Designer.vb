﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form13
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_etmanipu = New System.Windows.Forms.Button()
        Me.btn_econtro = New System.Windows.Forms.Button()
        Me.btn_edrog = New System.Windows.Forms.Button()
        Me.btn_pedimanipu = New System.Windows.Forms.Button()
        Me.btn_pedcontro = New System.Windows.Forms.Button()
        Me.btn_pedrogaria = New System.Windows.Forms.Button()
        Me.btn_cadfun = New System.Windows.Forms.Button()
        Me.btn_delfun = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_fechar = New System.Windows.Forms.ToolStripButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn_etmanipu
        '
        Me.btn_etmanipu.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_etmanipu.Location = New System.Drawing.Point(519, 48)
        Me.btn_etmanipu.Name = "btn_etmanipu"
        Me.btn_etmanipu.Size = New System.Drawing.Size(179, 40)
        Me.btn_etmanipu.TabIndex = 0
        Me.btn_etmanipu.Text = "ESTOQUE MANIPULAVEIS"
        Me.btn_etmanipu.UseVisualStyleBackColor = False
        '
        'btn_econtro
        '
        Me.btn_econtro.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_econtro.Location = New System.Drawing.Point(519, 171)
        Me.btn_econtro.Name = "btn_econtro"
        Me.btn_econtro.Size = New System.Drawing.Size(179, 40)
        Me.btn_econtro.TabIndex = 1
        Me.btn_econtro.Text = "ESTOQUE CONTROLADOS"
        Me.btn_econtro.UseVisualStyleBackColor = False
        '
        'btn_edrog
        '
        Me.btn_edrog.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_edrog.Location = New System.Drawing.Point(519, 299)
        Me.btn_edrog.Name = "btn_edrog"
        Me.btn_edrog.Size = New System.Drawing.Size(179, 40)
        Me.btn_edrog.TabIndex = 2
        Me.btn_edrog.Text = "ESTOQUE DROGARIA"
        Me.btn_edrog.UseVisualStyleBackColor = False
        '
        'btn_pedimanipu
        '
        Me.btn_pedimanipu.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_pedimanipu.Location = New System.Drawing.Point(47, 49)
        Me.btn_pedimanipu.Name = "btn_pedimanipu"
        Me.btn_pedimanipu.Size = New System.Drawing.Size(179, 40)
        Me.btn_pedimanipu.TabIndex = 3
        Me.btn_pedimanipu.Text = "PEDIDOS MANIPULAVEIS"
        Me.btn_pedimanipu.UseVisualStyleBackColor = False
        '
        'btn_pedcontro
        '
        Me.btn_pedcontro.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_pedcontro.Location = New System.Drawing.Point(47, 171)
        Me.btn_pedcontro.Name = "btn_pedcontro"
        Me.btn_pedcontro.Size = New System.Drawing.Size(179, 40)
        Me.btn_pedcontro.TabIndex = 4
        Me.btn_pedcontro.Text = "PEDIDOS CONTROLADOS"
        Me.btn_pedcontro.UseVisualStyleBackColor = False
        '
        'btn_pedrogaria
        '
        Me.btn_pedrogaria.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_pedrogaria.Location = New System.Drawing.Point(47, 299)
        Me.btn_pedrogaria.Name = "btn_pedrogaria"
        Me.btn_pedrogaria.Size = New System.Drawing.Size(179, 40)
        Me.btn_pedrogaria.TabIndex = 5
        Me.btn_pedrogaria.Text = "PEDIDOS DROGARIA"
        Me.btn_pedrogaria.UseVisualStyleBackColor = False
        '
        'btn_cadfun
        '
        Me.btn_cadfun.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_cadfun.Location = New System.Drawing.Point(288, 50)
        Me.btn_cadfun.Name = "btn_cadfun"
        Me.btn_cadfun.Size = New System.Drawing.Size(188, 39)
        Me.btn_cadfun.TabIndex = 7
        Me.btn_cadfun.Text = "CADASTRAR FUNCIONARIO"
        Me.btn_cadfun.UseVisualStyleBackColor = False
        '
        'btn_delfun
        '
        Me.btn_delfun.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.btn_delfun.Location = New System.Drawing.Point(288, 300)
        Me.btn_delfun.Name = "btn_delfun"
        Me.btn_delfun.Size = New System.Drawing.Size(188, 39)
        Me.btn_delfun.TabIndex = 8
        Me.btn_delfun.Text = "DELETAR FUNCIONARIO"
        Me.btn_delfun.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.druida_pharmacos.My.Resources.Resources.img_druida4
        Me.PictureBox1.Location = New System.Drawing.Point(288, 111)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(188, 160)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_fechar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(759, 25)
        Me.ToolStrip1.TabIndex = 9
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_fechar
        '
        Me.btn_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_fechar.Image = Global.druida_pharmacos.My.Resources.Resources.close_2_icon
        Me.btn_fechar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_fechar.Name = "btn_fechar"
        Me.btn_fechar.Size = New System.Drawing.Size(23, 22)
        Me.btn_fechar.Text = "FECHAR"
        '
        'Form13
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(759, 377)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.btn_delfun)
        Me.Controls.Add(Me.btn_cadfun)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btn_pedrogaria)
        Me.Controls.Add(Me.btn_pedcontro)
        Me.Controls.Add(Me.btn_pedimanipu)
        Me.Controls.Add(Me.btn_edrog)
        Me.Controls.Add(Me.btn_econtro)
        Me.Controls.Add(Me.btn_etmanipu)
        Me.Name = "Form13"
        Me.Text = "MENU DO GERENTE"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_etmanipu As Button
    Friend WithEvents btn_econtro As Button
    Friend WithEvents btn_edrog As Button
    Friend WithEvents btn_pedimanipu As Button
    Friend WithEvents btn_pedcontro As Button
    Friend WithEvents btn_pedrogaria As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btn_cadfun As Button
    Friend WithEvents btn_delfun As Button
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_fechar As ToolStripButton
End Class
