﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txt_preco1 = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.btn_save1 = New System.Windows.Forms.Button()
        Me.cmb_esp = New System.Windows.Forms.ComboBox()
        Me.txt_mg1 = New System.Windows.Forms.TextBox()
        Me.txt_fml1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_pres1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txt_pa1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txt_data1 = New System.Windows.Forms.DateTimePicker()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txt_cpf1 = New System.Windows.Forms.MaskedTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txt_nome1 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txt_preco2 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txt_save2 = New System.Windows.Forms.Button()
        Me.cmb_esp2 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_mg2 = New System.Windows.Forms.TextBox()
        Me.txt_fml2 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_pres2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txt_sub1 = New System.Windows.Forms.TextBox()
        Me.txt_data2 = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_cpf2 = New System.Windows.Forms.MaskedTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_nome2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txt_preco3 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txt_save3 = New System.Windows.Forms.Button()
        Me.cmb_esp3 = New System.Windows.Forms.ComboBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txt_mg3 = New System.Windows.Forms.TextBox()
        Me.txt_fml3 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txt_pres3 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txt_sub2 = New System.Windows.Forms.TextBox()
        Me.txt_data3 = New System.Windows.Forms.DateTimePicker()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txt_cpf3 = New System.Windows.Forms.MaskedTextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txt_nome3 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_fechar = New System.Windows.Forms.ToolStripButton()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(5, 29)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(592, 453)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txt_preco1)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.btn_save1)
        Me.TabPage1.Controls.Add(Me.cmb_esp)
        Me.TabPage1.Controls.Add(Me.txt_mg1)
        Me.TabPage1.Controls.Add(Me.txt_fml1)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.txt_pres1)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.txt_pa1)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.txt_data1)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.txt_cpf1)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.txt_nome1)
        Me.TabPage1.Controls.Add(Me.Label20)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(584, 427)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "REMÉDIOS MANIPULÁVEIS"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txt_preco1
        '
        Me.txt_preco1.Location = New System.Drawing.Point(274, 382)
        Me.txt_preco1.Name = "txt_preco1"
        Me.txt_preco1.Size = New System.Drawing.Size(53, 20)
        Me.txt_preco1.TabIndex = 80
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(227, 361)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(100, 16)
        Me.Label31.TabIndex = 79
        Me.Label31.Text = "               PREÇO"
        '
        'btn_save1
        '
        Me.btn_save1.BackColor = System.Drawing.Color.White
        Me.btn_save1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn_save1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_save1.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.btn_save1.Location = New System.Drawing.Point(6, 6)
        Me.btn_save1.Name = "btn_save1"
        Me.btn_save1.Size = New System.Drawing.Size(41, 32)
        Me.btn_save1.TabIndex = 78
        Me.btn_save1.UseVisualStyleBackColor = False
        '
        'cmb_esp
        '
        Me.cmb_esp.FormattingEnabled = True
        Me.cmb_esp.Location = New System.Drawing.Point(324, 328)
        Me.cmb_esp.Name = "cmb_esp"
        Me.cmb_esp.Size = New System.Drawing.Size(129, 21)
        Me.cmb_esp.TabIndex = 77
        '
        'txt_mg1
        '
        Me.txt_mg1.Location = New System.Drawing.Point(134, 329)
        Me.txt_mg1.Name = "txt_mg1"
        Me.txt_mg1.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg1.TabIndex = 76
        '
        'txt_fml1
        '
        Me.txt_fml1.Location = New System.Drawing.Point(135, 209)
        Me.txt_fml1.Name = "txt_fml1"
        Me.txt_fml1.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml1.TabIndex = 75
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(132, 190)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(253, 16)
        Me.Label9.TabIndex = 74
        Me.Label9.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_pres1
        '
        Me.txt_pres1.Location = New System.Drawing.Point(134, 154)
        Me.txt_pres1.Name = "txt_pres1"
        Me.txt_pres1.Size = New System.Drawing.Size(318, 20)
        Me.txt_pres1.TabIndex = 73
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(131, 135)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(162, 16)
        Me.Label12.TabIndex = 72
        Me.Label12.Text = "NOME DO PRESCRITOR"
        '
        'txt_pa1
        '
        Me.txt_pa1.Location = New System.Drawing.Point(135, 267)
        Me.txt_pa1.Name = "txt_pa1"
        Me.txt_pa1.Size = New System.Drawing.Size(318, 20)
        Me.txt_pa1.TabIndex = 71
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(321, 308)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(113, 16)
        Me.Label13.TabIndex = 70
        Me.Label13.Text = "ESPECIFICAÇÃO"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(321, 308)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(0, 16)
        Me.Label14.TabIndex = 69
        '
        'txt_data1
        '
        Me.txt_data1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txt_data1.Location = New System.Drawing.Point(306, 44)
        Me.txt_data1.Name = "txt_data1"
        Me.txt_data1.Size = New System.Drawing.Size(144, 20)
        Me.txt_data1.TabIndex = 68
        Me.txt_data1.Value = New Date(2019, 10, 29, 0, 0, 0, 0)
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(302, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(119, 20)
        Me.Label15.TabIndex = 67
        Me.Label15.Text = "DATA DO PEDIDO"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(131, 308)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(144, 16)
        Me.Label16.TabIndex = 66
        Me.Label16.Text = "QUANTIDADE EM MG"
        '
        'txt_cpf1
        '
        Me.txt_cpf1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_cpf1.Location = New System.Drawing.Point(135, 44)
        Me.txt_cpf1.Mask = "999,999,999-99"
        Me.txt_cpf1.Name = "txt_cpf1"
        Me.txt_cpf1.Size = New System.Drawing.Size(110, 20)
        Me.txt_cpf1.TabIndex = 65
        Me.txt_cpf1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(131, 24)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(115, 20)
        Me.Label17.TabIndex = 64
        Me.Label17.Text = "CPF DO CLIENTE"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(131, 264)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(0, 16)
        Me.Label18.TabIndex = 63
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(131, 244)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(117, 16)
        Me.Label19.TabIndex = 62
        Me.Label19.Text = "PRINCÍPIO ATIVO"
        '
        'txt_nome1
        '
        Me.txt_nome1.Location = New System.Drawing.Point(135, 101)
        Me.txt_nome1.Name = "txt_nome1"
        Me.txt_nome1.Size = New System.Drawing.Size(318, 20)
        Me.txt_nome1.TabIndex = 61
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(132, 82)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(130, 16)
        Me.Label20.TabIndex = 60
        Me.Label20.Text = "NOME DO CLIENTE"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txt_preco2)
        Me.TabPage2.Controls.Add(Me.Label32)
        Me.TabPage2.Controls.Add(Me.txt_save2)
        Me.TabPage2.Controls.Add(Me.cmb_esp2)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.txt_mg2)
        Me.TabPage2.Controls.Add(Me.txt_fml2)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.txt_pres2)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.txt_sub1)
        Me.TabPage2.Controls.Add(Me.txt_data2)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.txt_cpf2)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.txt_nome2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(584, 411)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "REMÉDIOS CONTROLADOS"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txt_preco2
        '
        Me.txt_preco2.Location = New System.Drawing.Point(272, 382)
        Me.txt_preco2.Name = "txt_preco2"
        Me.txt_preco2.Size = New System.Drawing.Size(55, 20)
        Me.txt_preco2.TabIndex = 100
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(227, 361)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(100, 16)
        Me.Label32.TabIndex = 99
        Me.Label32.Text = "               PREÇO"
        '
        'txt_save2
        '
        Me.txt_save2.BackColor = System.Drawing.Color.White
        Me.txt_save2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.txt_save2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_save2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txt_save2.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.txt_save2.Location = New System.Drawing.Point(6, 6)
        Me.txt_save2.Name = "txt_save2"
        Me.txt_save2.Size = New System.Drawing.Size(41, 32)
        Me.txt_save2.TabIndex = 98
        Me.txt_save2.UseVisualStyleBackColor = False
        '
        'cmb_esp2
        '
        Me.cmb_esp2.FormattingEnabled = True
        Me.cmb_esp2.Location = New System.Drawing.Point(324, 328)
        Me.cmb_esp2.Name = "cmb_esp2"
        Me.cmb_esp2.Size = New System.Drawing.Size(129, 21)
        Me.cmb_esp2.TabIndex = 97
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(321, 308)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 16)
        Me.Label7.TabIndex = 96
        Me.Label7.Text = "ESPECIFICAÇÃO"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(321, 308)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 16)
        Me.Label8.TabIndex = 95
        '
        'txt_mg2
        '
        Me.txt_mg2.Location = New System.Drawing.Point(134, 329)
        Me.txt_mg2.Name = "txt_mg2"
        Me.txt_mg2.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg2.TabIndex = 94
        '
        'txt_fml2
        '
        Me.txt_fml2.Location = New System.Drawing.Point(135, 209)
        Me.txt_fml2.Name = "txt_fml2"
        Me.txt_fml2.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml2.TabIndex = 93
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(132, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(253, 16)
        Me.Label11.TabIndex = 92
        Me.Label11.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_pres2
        '
        Me.txt_pres2.Location = New System.Drawing.Point(134, 154)
        Me.txt_pres2.Name = "txt_pres2"
        Me.txt_pres2.Size = New System.Drawing.Size(318, 20)
        Me.txt_pres2.TabIndex = 91
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(131, 135)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(162, 16)
        Me.Label10.TabIndex = 90
        Me.Label10.Text = "NOME DO PRESCRITOR"
        '
        'txt_sub1
        '
        Me.txt_sub1.Location = New System.Drawing.Point(135, 269)
        Me.txt_sub1.Name = "txt_sub1"
        Me.txt_sub1.Size = New System.Drawing.Size(318, 20)
        Me.txt_sub1.TabIndex = 89
        '
        'txt_data2
        '
        Me.txt_data2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txt_data2.Location = New System.Drawing.Point(306, 44)
        Me.txt_data2.Name = "txt_data2"
        Me.txt_data2.Size = New System.Drawing.Size(144, 20)
        Me.txt_data2.TabIndex = 88
        Me.txt_data2.Value = New Date(2019, 10, 29, 0, 0, 0, 0)
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(302, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 20)
        Me.Label6.TabIndex = 87
        Me.Label6.Text = "DATA DO PEDIDO"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(131, 308)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(144, 16)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "QUANTIDADE EM MG"
        '
        'txt_cpf2
        '
        Me.txt_cpf2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_cpf2.Location = New System.Drawing.Point(135, 44)
        Me.txt_cpf2.Mask = "999,999,999-99"
        Me.txt_cpf2.Name = "txt_cpf2"
        Me.txt_cpf2.Size = New System.Drawing.Size(110, 20)
        Me.txt_cpf2.TabIndex = 85
        Me.txt_cpf2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(131, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(115, 20)
        Me.Label4.TabIndex = 84
        Me.Label4.Text = "CPF DO CLIENTE"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(131, 266)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 16)
        Me.Label3.TabIndex = 83
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(131, 246)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(159, 16)
        Me.Label2.TabIndex = 82
        Me.Label2.Text = "NOME DA SUBSTÂNCIA"
        '
        'txt_nome2
        '
        Me.txt_nome2.Location = New System.Drawing.Point(135, 101)
        Me.txt_nome2.Name = "txt_nome2"
        Me.txt_nome2.Size = New System.Drawing.Size(318, 20)
        Me.txt_nome2.TabIndex = 81
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(132, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 16)
        Me.Label1.TabIndex = 80
        Me.Label1.Text = "NOME DO CLIENTE"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.txt_preco3)
        Me.TabPage3.Controls.Add(Me.Label33)
        Me.TabPage3.Controls.Add(Me.txt_save3)
        Me.TabPage3.Controls.Add(Me.cmb_esp3)
        Me.TabPage3.Controls.Add(Me.Label23)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.txt_mg3)
        Me.TabPage3.Controls.Add(Me.txt_fml3)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.txt_pres3)
        Me.TabPage3.Controls.Add(Me.Label22)
        Me.TabPage3.Controls.Add(Me.txt_sub2)
        Me.TabPage3.Controls.Add(Me.txt_data3)
        Me.TabPage3.Controls.Add(Me.Label25)
        Me.TabPage3.Controls.Add(Me.Label26)
        Me.TabPage3.Controls.Add(Me.txt_cpf3)
        Me.TabPage3.Controls.Add(Me.Label27)
        Me.TabPage3.Controls.Add(Me.Label28)
        Me.TabPage3.Controls.Add(Me.Label29)
        Me.TabPage3.Controls.Add(Me.txt_nome3)
        Me.TabPage3.Controls.Add(Me.Label30)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(584, 411)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "DROGARIA"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'txt_preco3
        '
        Me.txt_preco3.Location = New System.Drawing.Point(273, 382)
        Me.txt_preco3.Name = "txt_preco3"
        Me.txt_preco3.Size = New System.Drawing.Size(54, 20)
        Me.txt_preco3.TabIndex = 115
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(227, 361)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(100, 16)
        Me.Label33.TabIndex = 114
        Me.Label33.Text = "               PREÇO"
        '
        'txt_save3
        '
        Me.txt_save3.BackColor = System.Drawing.Color.White
        Me.txt_save3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.txt_save3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_save3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txt_save3.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.txt_save3.Location = New System.Drawing.Point(6, 6)
        Me.txt_save3.Name = "txt_save3"
        Me.txt_save3.Size = New System.Drawing.Size(41, 32)
        Me.txt_save3.TabIndex = 113
        Me.txt_save3.UseVisualStyleBackColor = False
        '
        'cmb_esp3
        '
        Me.cmb_esp3.FormattingEnabled = True
        Me.cmb_esp3.Location = New System.Drawing.Point(324, 328)
        Me.cmb_esp3.Name = "cmb_esp3"
        Me.cmb_esp3.Size = New System.Drawing.Size(129, 21)
        Me.cmb_esp3.TabIndex = 112
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(321, 308)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(113, 16)
        Me.Label23.TabIndex = 111
        Me.Label23.Text = "ESPECIFICAÇÃO"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(321, 308)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(0, 16)
        Me.Label24.TabIndex = 110
        '
        'txt_mg3
        '
        Me.txt_mg3.Location = New System.Drawing.Point(134, 329)
        Me.txt_mg3.Name = "txt_mg3"
        Me.txt_mg3.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg3.TabIndex = 109
        '
        'txt_fml3
        '
        Me.txt_fml3.Location = New System.Drawing.Point(135, 209)
        Me.txt_fml3.Name = "txt_fml3"
        Me.txt_fml3.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml3.TabIndex = 108
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(132, 190)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(253, 16)
        Me.Label21.TabIndex = 107
        Me.Label21.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_pres3
        '
        Me.txt_pres3.Location = New System.Drawing.Point(134, 154)
        Me.txt_pres3.Name = "txt_pres3"
        Me.txt_pres3.Size = New System.Drawing.Size(318, 20)
        Me.txt_pres3.TabIndex = 106
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(131, 135)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(162, 16)
        Me.Label22.TabIndex = 105
        Me.Label22.Text = "NOME DO PRESCRITOR"
        '
        'txt_sub2
        '
        Me.txt_sub2.Location = New System.Drawing.Point(135, 269)
        Me.txt_sub2.Name = "txt_sub2"
        Me.txt_sub2.Size = New System.Drawing.Size(318, 20)
        Me.txt_sub2.TabIndex = 104
        '
        'txt_data3
        '
        Me.txt_data3.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.txt_data3.Location = New System.Drawing.Point(306, 44)
        Me.txt_data3.Name = "txt_data3"
        Me.txt_data3.Size = New System.Drawing.Size(144, 20)
        Me.txt_data3.TabIndex = 103
        Me.txt_data3.Value = New Date(2019, 10, 29, 0, 0, 0, 0)
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(302, 24)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(119, 20)
        Me.Label25.TabIndex = 102
        Me.Label25.Text = "DATA DO PEDIDO"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(131, 308)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(144, 16)
        Me.Label26.TabIndex = 101
        Me.Label26.Text = "QUANTIDADE EM MG"
        '
        'txt_cpf3
        '
        Me.txt_cpf3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_cpf3.Location = New System.Drawing.Point(135, 44)
        Me.txt_cpf3.Mask = "999,999,999-99"
        Me.txt_cpf3.Name = "txt_cpf3"
        Me.txt_cpf3.Size = New System.Drawing.Size(110, 20)
        Me.txt_cpf3.TabIndex = 100
        Me.txt_cpf3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(131, 24)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(115, 20)
        Me.Label27.TabIndex = 99
        Me.Label27.Text = "CPF DO CLIENTE"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(131, 266)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(0, 16)
        Me.Label28.TabIndex = 98
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(131, 246)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(159, 16)
        Me.Label29.TabIndex = 97
        Me.Label29.Text = "NOME DA SUBSTÂNCIA"
        '
        'txt_nome3
        '
        Me.txt_nome3.Location = New System.Drawing.Point(135, 101)
        Me.txt_nome3.Name = "txt_nome3"
        Me.txt_nome3.Size = New System.Drawing.Size(318, 20)
        Me.txt_nome3.TabIndex = 96
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(132, 82)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(130, 16)
        Me.Label30.TabIndex = 95
        Me.Label30.Text = "NOME DO CLIENTE"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_fechar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(600, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_fechar
        '
        Me.btn_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_fechar.Image = Global.druida_pharmacos.My.Resources.Resources.close_2_icon
        Me.btn_fechar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_fechar.Name = "btn_fechar"
        Me.btn_fechar.Size = New System.Drawing.Size(23, 22)
        Me.btn_fechar.Text = "FECHAR"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 494)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form4"
        Me.Text = "PEDIDOS"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents cmb_esp As ComboBox
    Friend WithEvents txt_mg1 As TextBox
    Friend WithEvents txt_fml1 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_pres1 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txt_pa1 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txt_data1 As DateTimePicker
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txt_cpf1 As MaskedTextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents txt_nome1 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents cmb_esp2 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_mg2 As TextBox
    Friend WithEvents txt_fml2 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txt_pres2 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_sub1 As TextBox
    Friend WithEvents txt_data2 As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_cpf2 As MaskedTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_nome2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents txt_mg3 As TextBox
    Friend WithEvents txt_fml3 As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txt_pres3 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txt_sub2 As TextBox
    Friend WithEvents txt_data3 As DateTimePicker
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents txt_cpf3 As MaskedTextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents txt_nome3 As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents cmb_esp3 As ComboBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents btn_save1 As Button
    Friend WithEvents txt_save2 As Button
    Friend WithEvents txt_save3 As Button
    Friend WithEvents txt_preco1 As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents txt_preco2 As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents txt_preco3 As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_fechar As ToolStripButton
End Class
