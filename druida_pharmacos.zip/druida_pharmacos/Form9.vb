﻿Public Class Form9

    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        camp_estoque_drogaria()
        gerar_dados_drogaria()

    End Sub

    Private Sub dgv_dados2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados2.CellContentClick

        Try


            With dgv_dados2
                If .CurrentRow.Cells(7).Selected = True Then
                    aux = .CurrentRow.Cells(1).Value.ToString
                    resp = MsgBox("Deseja deletar o registro" + vbNewLine &
                                  "Fórmula:" & aux & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = "delete * from tb_edrogaria where fml3= '" & aux & "'"
                        rs = db.Execute(sql)
                        gerar_dados_drogaria()
                    End If

                Else
                    Exit Sub

                End If

            End With

        Catch ex As Exception
            MsgBox("Deu RUIM ARTHUR!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Private Sub txt_busca2_TextChanged(sender As Object, e As EventArgs) Handles txt_busca2.TextChanged

        sql = "select * from tb_edrogaria where " & cmb_camp3.Text & " like '" & txt_busca2.Text & "%'"
        rs = db.Execute(sql)
        cont = 1
        With dgv_dados2
            .Rows.Clear()
            Do While rs.EOF = False

                .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(1).Value, rs.Fields(2).Value, rs.Fields(3).Value, rs.Fields(4).Value, rs.Fields(5).Value, Nothing, Nothing)
                rs.MoveNext()
                cont = cont + 1
            Loop
        End With


    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form13.Show()


    End Sub
End Class