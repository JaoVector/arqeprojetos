﻿Public Class Form8
    Private Sub txt_cadcliente_Click(sender As Object, e As EventArgs) Handles txt_cadcliente.Click

        Form1.ShowDialog()


    End Sub

    Private Sub txt_cadpedido_Click(sender As Object, e As EventArgs) Handles txt_cadpedido.Click

        Form4.ShowDialog()


    End Sub

    Private Sub txt_cadprodutos_Click(sender As Object, e As EventArgs) Handles txt_cadprodutos.Click

        Form3.ShowDialog()


    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form2.Show()


    End Sub


End Class