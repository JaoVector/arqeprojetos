﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form8
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt_cadcliente = New System.Windows.Forms.Button()
        Me.txt_cadpedido = New System.Windows.Forms.Button()
        Me.txt_cadprodutos = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_fechar = New System.Windows.Forms.ToolStripButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_cadcliente
        '
        Me.txt_cadcliente.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.txt_cadcliente.Location = New System.Drawing.Point(41, 66)
        Me.txt_cadcliente.Name = "txt_cadcliente"
        Me.txt_cadcliente.Size = New System.Drawing.Size(163, 42)
        Me.txt_cadcliente.TabIndex = 0
        Me.txt_cadcliente.Text = "CADASTRO DE CLIENTES"
        Me.txt_cadcliente.UseVisualStyleBackColor = False
        '
        'txt_cadpedido
        '
        Me.txt_cadpedido.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.txt_cadpedido.Location = New System.Drawing.Point(41, 154)
        Me.txt_cadpedido.Name = "txt_cadpedido"
        Me.txt_cadpedido.Size = New System.Drawing.Size(163, 42)
        Me.txt_cadpedido.TabIndex = 1
        Me.txt_cadpedido.Text = "CADASTRO DE PEDIDOS"
        Me.txt_cadpedido.UseVisualStyleBackColor = False
        '
        'txt_cadprodutos
        '
        Me.txt_cadprodutos.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.txt_cadprodutos.Location = New System.Drawing.Point(41, 246)
        Me.txt_cadprodutos.Name = "txt_cadprodutos"
        Me.txt_cadprodutos.Size = New System.Drawing.Size(163, 42)
        Me.txt_cadprodutos.TabIndex = 2
        Me.txt_cadprodutos.Text = "CADASTRO DE PRODUTOS"
        Me.txt_cadprodutos.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.druida_pharmacos.My.Resources.Resources.img_druida4
        Me.PictureBox1.Location = New System.Drawing.Point(307, 96)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(182, 153)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_fechar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(548, 25)
        Me.ToolStrip1.TabIndex = 4
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_fechar
        '
        Me.btn_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_fechar.Image = Global.druida_pharmacos.My.Resources.Resources.close_2_icon
        Me.btn_fechar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_fechar.Name = "btn_fechar"
        Me.btn_fechar.Size = New System.Drawing.Size(23, 22)
        Me.btn_fechar.Text = "FECHAR"
        '
        'Form8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(548, 347)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txt_cadprodutos)
        Me.Controls.Add(Me.txt_cadpedido)
        Me.Controls.Add(Me.txt_cadcliente)
        Me.Name = "Form8"
        Me.Text = "MENU FUNCIONÁRIO"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_cadcliente As Button
    Friend WithEvents txt_cadpedido As Button
    Friend WithEvents txt_cadprodutos As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_fechar As ToolStripButton
End Class
