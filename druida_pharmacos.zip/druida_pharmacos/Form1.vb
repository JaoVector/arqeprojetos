﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        gerar_dados()
        carregar_campos()

    End Sub

    Private Sub txt_cep_LostFocus(sender As Object, e As EventArgs) Handles txt_cep.LostFocus

        Try

            sql = "select * from tb_cep where cep='" & txt_cep.Text & "'"
            rs = db.Execute(sql)
            If rs.EOF = False Then

                txt_endereco.Text = rs.Fields(1).Value
                txt_bairro.Text = rs.Fields(2).Value
                txt_city.Text = rs.Fields(3).Value
                txt_uf.Text = rs.Fields(4).Value
                txt_comp.Focus()

            Else

                MsgBox("CEP não Localizado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")

            End If
        Catch ex As Exception

            MsgBox("ERRO AO PROCESSAR!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "ATENÇÃO")

        End Try




    End Sub

    Private Sub img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click

        Try

            With OpenFileDialog1

                .Title = "SELECIONE UMA IMAGEM DE PERFIL"
                .InitialDirectory = Application.StartupPath & "\Fotos"
                .ShowDialog()
                diretorio = .FileName
                img_foto.Load(diretorio)

            End With

        Catch ex As Exception
            Exit Sub
        End Try
    End Sub



    Private Sub btn_salvar_Click(sender As Object, e As EventArgs) Handles btn_salvar.Click

        Try

            sql = "insert into tb_cadastro values ('" & txt_cpf.Text & "', " & _
                                                "'" & txt_data.Text & "', " & _
                                                "'" & txt_nome.Text & "', " & _
                                                "'" & txt_cep.Text & "', " & _
                                                "'" & txt_endereco.Text & "', " & _
                                                "'" & txt_comp.Text & "', " & _
                                                "'" & txt_bairro.Text & "', " & _
                                                "'" & txt_city.Text & "', " & _
                                                "'" & txt_uf.Text & "', " & _
                                                "'" & txt_fone.Text & "', " & _
                                                "'" & txt_cel.Text & "', " & _
                                                "'" & txt_email.Text & "', " & _
                                                "'" & diretorio & "')"
            rs = db.Execute(UCase(sql))
            MsgBox("Cadastro Efetuado com Sucesso!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            limpar_cadastro()
        Catch ex As Exception
            MsgBox("Erro ao Gravar!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub


    Private Sub txt_busca_TextChanged(sender As Object, e As EventArgs) Handles txt_busca.TextChanged

        Try

            sql = "select * from tb_cadastro where " & cmb_campo.Text & " like '" & txt_busca.Text & "%'"
            rs = db.Execute(sql)
            cont = 1
            With dgv_dados
                .Rows.Clear()
                Do While rs.EOF = False
                    .Rows.Add(cont, rs.Fields(0).Value, rs.Fields(2).Value, Nothing)
                    rs.MoveNext()
                    cont = cont + 1
                Loop
            End With

        Catch ex As Exception
            MsgBox("Erro ao Efetuar a Pesquisa!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Private Sub dgv_dados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv_dados.CellContentClick

        Try


            With dgv_dados
                If .CurrentRow.Cells(3).Selected = True Then
                    aux = .CurrentRow.Cells(1).Value.ToString
                    resp = MsgBox("Deseja deletar o Funcionario do" + vbNewLine &
                                  "CPF:" & aux & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "ATENÇÃO")
                    If resp = MsgBoxResult.Yes Then
                        sql = "delete * from tb_cadastro where cpf= '" & aux & "'"
                        rs = db.Execute(sql)
                        gerar_dados()
                    End If

                Else
                    Exit Sub

                End If

            End With

        Catch ex As Exception
            MsgBox("Deu RUIM ARTHUR!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try

    End Sub

    Private Sub btn_fechar_Click(sender As Object, e As EventArgs) Handles btn_fechar.Click

        Me.Close()
        Form8.Show()

    End Sub
End Class
