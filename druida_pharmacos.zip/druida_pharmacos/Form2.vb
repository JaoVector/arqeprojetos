﻿Public Class Form2

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conecta_banco()
        categ_funcio_login()

    End Sub

    Private Sub btn_enter_Click(sender As Object, e As EventArgs) Handles btn_enter.Click




        sql = "select * from tb_funcionarios where cpf='" & txt_cpf.Text & "' And categoria= '" & cmb_categ.Text & "'"
        rs = db.Execute(sql)
        If rs.EOF = False Then
            MsgBox("Logado Com Sucesso!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            If cmb_categ.Text = "GERENTE" Then
                Form13.ShowDialog()


            ElseIf cmb_categ.Text = "FUNCIONÁRIO" Then

                Form8.ShowDialog()



            ElseIf cmb_categ.Text = "" Or txt_cpf.Text = "" Then
                MsgBox("Preencha Todos os Campos!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
            Else
                MsgBox("Os dados não Conferem!!!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                With Me
                    .cmb_categ.SelectedIndex = 0
                    .txt_cpf.Clear()
                    .txt_cpf.Focus()

                End With
            End If
        End If

    End Sub


End Class