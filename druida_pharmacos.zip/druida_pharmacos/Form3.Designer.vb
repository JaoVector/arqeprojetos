﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.tab_control22 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.qtd1 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txt_preco1 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.btn_save1 = New System.Windows.Forms.Button()
        Me.cmb_esp = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txt_mg1 = New System.Windows.Forms.TextBox()
        Me.txt_fml1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_pa1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.qtd2 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txt_preco2 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.btn_salvar2 = New System.Windows.Forms.Button()
        Me.cmb_esp2 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_mg2 = New System.Windows.Forms.TextBox()
        Me.txt_fml2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_sub1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.qtd3 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txt_preco3 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.cmb_esp3 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.btn_salvar3 = New System.Windows.Forms.Button()
        Me.txt_mg3 = New System.Windows.Forms.TextBox()
        Me.txt_fml3 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txt_sub2 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btn_fechar = New System.Windows.Forms.ToolStripButton()
        Me.tab_control22.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tab_control22
        '
        Me.tab_control22.Controls.Add(Me.TabPage1)
        Me.tab_control22.Controls.Add(Me.TabPage2)
        Me.tab_control22.Controls.Add(Me.TabPage3)
        Me.tab_control22.Location = New System.Drawing.Point(11, 34)
        Me.tab_control22.Name = "tab_control22"
        Me.tab_control22.SelectedIndex = 0
        Me.tab_control22.Size = New System.Drawing.Size(610, 333)
        Me.tab_control22.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.qtd1)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.txt_preco1)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.btn_save1)
        Me.TabPage1.Controls.Add(Me.cmb_esp)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.txt_mg1)
        Me.TabPage1.Controls.Add(Me.txt_fml1)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.txt_pa1)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(602, 307)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "ESTOQUE DE MANIPULAVÉIS"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'qtd1
        '
        Me.qtd1.Location = New System.Drawing.Point(322, 262)
        Me.qtd1.Name = "qtd1"
        Me.qtd1.Size = New System.Drawing.Size(141, 20)
        Me.qtd1.TabIndex = 79
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(318, 241)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(100, 16)
        Me.Label22.TabIndex = 78
        Me.Label22.Text = " QUANTIDADE"
        '
        'txt_preco1
        '
        Me.txt_preco1.Location = New System.Drawing.Point(143, 262)
        Me.txt_preco1.Name = "txt_preco1"
        Me.txt_preco1.Size = New System.Drawing.Size(141, 20)
        Me.txt_preco1.TabIndex = 77
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(140, 241)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(58, 16)
        Me.Label19.TabIndex = 76
        Me.Label19.Text = " PREÇO"
        '
        'btn_save1
        '
        Me.btn_save1.BackColor = System.Drawing.Color.White
        Me.btn_save1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn_save1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_save1.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.btn_save1.Location = New System.Drawing.Point(6, 6)
        Me.btn_save1.Name = "btn_save1"
        Me.btn_save1.Size = New System.Drawing.Size(41, 32)
        Me.btn_save1.TabIndex = 75
        Me.btn_save1.UseVisualStyleBackColor = False
        '
        'cmb_esp
        '
        Me.cmb_esp.FormattingEnabled = True
        Me.cmb_esp.Location = New System.Drawing.Point(322, 205)
        Me.cmb_esp.Name = "cmb_esp"
        Me.cmb_esp.Size = New System.Drawing.Size(140, 21)
        Me.cmb_esp.TabIndex = 72
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(319, 185)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 16)
        Me.Label7.TabIndex = 71
        Me.Label7.Text = "ESPECIFICAÇÃO"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(330, 185)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(0, 16)
        Me.Label14.TabIndex = 70
        '
        'txt_mg1
        '
        Me.txt_mg1.Location = New System.Drawing.Point(143, 206)
        Me.txt_mg1.Name = "txt_mg1"
        Me.txt_mg1.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg1.TabIndex = 69
        '
        'txt_fml1
        '
        Me.txt_fml1.Location = New System.Drawing.Point(144, 81)
        Me.txt_fml1.Name = "txt_fml1"
        Me.txt_fml1.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml1.TabIndex = 68
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(141, 62)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(253, 16)
        Me.Label11.TabIndex = 67
        Me.Label11.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_pa1
        '
        Me.txt_pa1.Location = New System.Drawing.Point(144, 145)
        Me.txt_pa1.Name = "txt_pa1"
        Me.txt_pa1.Size = New System.Drawing.Size(318, 20)
        Me.txt_pa1.TabIndex = 66
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(140, 185)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(144, 16)
        Me.Label5.TabIndex = 65
        Me.Label5.Text = "QUANTIDADE EM MG"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(167, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 16)
        Me.Label3.TabIndex = 64
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(140, 122)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 16)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "PRINCÍPIO ATIVO"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.qtd2)
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.txt_preco2)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.btn_salvar2)
        Me.TabPage2.Controls.Add(Me.cmb_esp2)
        Me.TabPage2.Controls.Add(Me.Label4)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.txt_mg2)
        Me.TabPage2.Controls.Add(Me.txt_fml2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.txt_sub1)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(602, 311)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "ESTOQUE DE CONTROLADOS"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'qtd2
        '
        Me.qtd2.Location = New System.Drawing.Point(321, 262)
        Me.qtd2.Name = "qtd2"
        Me.qtd2.Size = New System.Drawing.Size(141, 20)
        Me.qtd2.TabIndex = 81
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(318, 241)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(97, 16)
        Me.Label23.TabIndex = 80
        Me.Label23.Text = "QUANTIDADE"
        '
        'txt_preco2
        '
        Me.txt_preco2.Location = New System.Drawing.Point(143, 262)
        Me.txt_preco2.Name = "txt_preco2"
        Me.txt_preco2.Size = New System.Drawing.Size(141, 20)
        Me.txt_preco2.TabIndex = 79
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(140, 241)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(55, 16)
        Me.Label20.TabIndex = 78
        Me.Label20.Text = "PREÇO"
        '
        'btn_salvar2
        '
        Me.btn_salvar2.BackColor = System.Drawing.Color.White
        Me.btn_salvar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn_salvar2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_salvar2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_salvar2.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.btn_salvar2.Location = New System.Drawing.Point(6, 6)
        Me.btn_salvar2.Name = "btn_salvar2"
        Me.btn_salvar2.Size = New System.Drawing.Size(41, 32)
        Me.btn_salvar2.TabIndex = 76
        Me.btn_salvar2.UseVisualStyleBackColor = False
        '
        'cmb_esp2
        '
        Me.cmb_esp2.FormattingEnabled = True
        Me.cmb_esp2.Location = New System.Drawing.Point(323, 205)
        Me.cmb_esp2.Name = "cmb_esp2"
        Me.cmb_esp2.Size = New System.Drawing.Size(139, 21)
        Me.cmb_esp2.TabIndex = 72
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(320, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 16)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = "ESPECIFICAÇÃO"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(330, 185)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 16)
        Me.Label6.TabIndex = 70
        '
        'txt_mg2
        '
        Me.txt_mg2.Location = New System.Drawing.Point(143, 206)
        Me.txt_mg2.Name = "txt_mg2"
        Me.txt_mg2.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg2.TabIndex = 69
        '
        'txt_fml2
        '
        Me.txt_fml2.Location = New System.Drawing.Point(144, 81)
        Me.txt_fml2.Name = "txt_fml2"
        Me.txt_fml2.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml2.TabIndex = 68
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(141, 62)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(253, 16)
        Me.Label1.TabIndex = 67
        Me.Label1.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_sub1
        '
        Me.txt_sub1.Location = New System.Drawing.Point(144, 145)
        Me.txt_sub1.Name = "txt_sub1"
        Me.txt_sub1.Size = New System.Drawing.Size(318, 20)
        Me.txt_sub1.TabIndex = 66
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(140, 185)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(144, 16)
        Me.Label9.TabIndex = 65
        Me.Label9.Text = "QUANTIDADE EM MG"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(167, 149)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(0, 16)
        Me.Label10.TabIndex = 64
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(140, 122)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(94, 16)
        Me.Label12.TabIndex = 63
        Me.Label12.Text = "SUBSTÂNCIA"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.qtd3)
        Me.TabPage3.Controls.Add(Me.Label24)
        Me.TabPage3.Controls.Add(Me.txt_preco3)
        Me.TabPage3.Controls.Add(Me.Label21)
        Me.TabPage3.Controls.Add(Me.cmb_esp3)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Controls.Add(Me.Label15)
        Me.TabPage3.Controls.Add(Me.btn_salvar3)
        Me.TabPage3.Controls.Add(Me.txt_mg3)
        Me.TabPage3.Controls.Add(Me.txt_fml3)
        Me.TabPage3.Controls.Add(Me.Label13)
        Me.TabPage3.Controls.Add(Me.txt_sub2)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.Label17)
        Me.TabPage3.Controls.Add(Me.Label18)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(602, 311)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "ESTOQUE DROGARIA"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'qtd3
        '
        Me.qtd3.Location = New System.Drawing.Point(321, 262)
        Me.qtd3.Name = "qtd3"
        Me.qtd3.Size = New System.Drawing.Size(141, 20)
        Me.qtd3.TabIndex = 87
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(318, 241)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(100, 16)
        Me.Label24.TabIndex = 86
        Me.Label24.Text = " QUANTIDADE"
        '
        'txt_preco3
        '
        Me.txt_preco3.Location = New System.Drawing.Point(144, 262)
        Me.txt_preco3.Name = "txt_preco3"
        Me.txt_preco3.Size = New System.Drawing.Size(141, 20)
        Me.txt_preco3.TabIndex = 85
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(141, 241)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(58, 16)
        Me.Label21.TabIndex = 84
        Me.Label21.Text = " PREÇO"
        '
        'cmb_esp3
        '
        Me.cmb_esp3.FormattingEnabled = True
        Me.cmb_esp3.Location = New System.Drawing.Point(321, 205)
        Me.cmb_esp3.Name = "cmb_esp3"
        Me.cmb_esp3.Size = New System.Drawing.Size(141, 21)
        Me.cmb_esp3.TabIndex = 83
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(318, 185)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 16)
        Me.Label8.TabIndex = 82
        Me.Label8.Text = "ESPECIFICAÇÃO"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(330, 185)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(0, 16)
        Me.Label15.TabIndex = 81
        '
        'btn_salvar3
        '
        Me.btn_salvar3.BackColor = System.Drawing.Color.White
        Me.btn_salvar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btn_salvar3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_salvar3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btn_salvar3.Image = Global.druida_pharmacos.My.Resources.Resources.Save_icon
        Me.btn_salvar3.Location = New System.Drawing.Point(6, 6)
        Me.btn_salvar3.Name = "btn_salvar3"
        Me.btn_salvar3.Size = New System.Drawing.Size(41, 32)
        Me.btn_salvar3.TabIndex = 80
        Me.btn_salvar3.UseVisualStyleBackColor = False
        '
        'txt_mg3
        '
        Me.txt_mg3.Location = New System.Drawing.Point(143, 206)
        Me.txt_mg3.Name = "txt_mg3"
        Me.txt_mg3.Size = New System.Drawing.Size(141, 20)
        Me.txt_mg3.TabIndex = 69
        '
        'txt_fml3
        '
        Me.txt_fml3.Location = New System.Drawing.Point(144, 81)
        Me.txt_fml3.Name = "txt_fml3"
        Me.txt_fml3.Size = New System.Drawing.Size(318, 20)
        Me.txt_fml3.TabIndex = 68
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(141, 62)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(253, 16)
        Me.Label13.TabIndex = 67
        Me.Label13.Text = "NÚMERO DE REGISTRO DA FÓRMULA"
        '
        'txt_sub2
        '
        Me.txt_sub2.Location = New System.Drawing.Point(144, 145)
        Me.txt_sub2.Name = "txt_sub2"
        Me.txt_sub2.Size = New System.Drawing.Size(318, 20)
        Me.txt_sub2.TabIndex = 66
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(140, 185)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(144, 16)
        Me.Label16.TabIndex = 65
        Me.Label16.Text = "QUANTIDADE EM MG"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(167, 149)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(0, 16)
        Me.Label17.TabIndex = 64
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(140, 122)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(94, 16)
        Me.Label18.TabIndex = 63
        Me.Label18.Text = "SUBSTÂNCIA"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_fechar})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(633, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btn_fechar
        '
        Me.btn_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btn_fechar.Image = Global.druida_pharmacos.My.Resources.Resources.close_2_icon
        Me.btn_fechar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_fechar.Name = "btn_fechar"
        Me.btn_fechar.Size = New System.Drawing.Size(23, 22)
        Me.btn_fechar.Text = "FECHAR"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(633, 379)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.tab_control22)
        Me.Name = "Form3"
        Me.Text = "ESTOQUE"
        Me.tab_control22.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tab_control22 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents cmb_esp As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txt_mg1 As TextBox
    Friend WithEvents txt_fml1 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txt_pa1 As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents cmb_esp2 As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_mg2 As TextBox
    Friend WithEvents txt_fml2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_sub1 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents txt_mg3 As TextBox
    Friend WithEvents txt_fml3 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txt_sub2 As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents btn_save1 As Button
    Friend WithEvents btn_salvar2 As Button
    Friend WithEvents btn_salvar3 As Button
    Friend WithEvents cmb_esp3 As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents txt_preco1 As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txt_preco2 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txt_preco3 As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents qtd1 As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents qtd2 As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents qtd3 As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents btn_fechar As ToolStripButton
End Class
