/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import javax.swing.JOptionPane;


/**
 *
 * @author Jo4oV
 */
public class Proprietario {
    
    private Veiculo veiculo; //Agregação
    private String nome;
    private String cpf;
   
    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Proprietario(Veiculo veiculo) {
        //instancia o objeto para a agregação
        veiculo = new Veiculo();
       
    }
    
     
    Set<Veiculo> addcar = new HashSet();
    
    public void AddVeiculo(Veiculo veiculo){
    
         if(this.addcar.size() <= 4){
             this.addcar.add(veiculo);
         }
         else{
             
             int escolha = JOptionPane.showConfirmDialog(null, "Voce Deseja Adicionar mais que 5 carros?", "Aviso", JOptionPane.YES_NO_OPTION);
             if(escolha == JOptionPane.YES_NO_OPTION){
                this.addcar.add(veiculo);
       
         }
         
         }
    }
    
    public float Valbens(){
       float total=0;
        Iterator<Veiculo> val = addcar.iterator();
        
         while(val.hasNext()) {
            //faz a leitura do próximo item da coleção
            Veiculo aux = val.next();
           total += aux.getValor();
        }
        
        return total;
    }
    
}
