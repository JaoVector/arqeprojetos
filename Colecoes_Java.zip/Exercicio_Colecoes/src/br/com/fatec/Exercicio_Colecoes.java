/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec;




/**
 *
 * @author Jo4oV
 */
public class Exercicio_Colecoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      Veiculo car = new Veiculo();
      Proprietario prop = new Proprietario(car);
      prop.setNome("Joao");
      prop.setCpf("43131414");
    
      
      car.setPlaca("123abc");
      car.setValor(100.000f);
     
      
      Veiculo car2 = new Veiculo();
      car2.setPlaca("432ada");
      car2.setValor(100.000f);
      
      
      Veiculo car3 = new Veiculo();
      car3.setPlaca("421eee");
      car3.setValor(100.000f);
      
       
      Veiculo car4 = new Veiculo();
      car4.setPlaca("353aht");
      car4.setValor(280.000f);
      
      
      Veiculo car5 = new Veiculo();
      car5.setPlaca("765jko");
      car5.setValor(280.000f);
      
        
      Veiculo car6 = new Veiculo();
      car6.setPlaca("095sjo");
      car6.setValor(280.000f);
     
  
      prop.AddVeiculo(car);
      prop.AddVeiculo(car2);
      prop.AddVeiculo(car3);
      prop.AddVeiculo(car4);
      prop.AddVeiculo(car5);
      prop.AddVeiculo(car6);

      
      System.out.println("Total: " + prop.Valbens());
      
      
     
      
      for(Veiculo aux : prop.addcar){
          System.out.println("Carros Pela Placa: " + aux.getPlaca());
          System.out.println("Carros Valor: " + aux.getValor());
          System.out.println("=======================================");
          
      }
     
  
    }   
}
